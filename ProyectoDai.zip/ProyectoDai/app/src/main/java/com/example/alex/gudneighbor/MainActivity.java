package com.example.alex.gudneighbor;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText usu, cont;

    String bund;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        usu=(EditText) findViewById(R.id.etUsuario);
        cont=(EditText) findViewById(R.id.etContraseña);


    }
    public void limpia(View v){
       usu.setText("");
       cont.setText("");
    }
    public void principal(View v) {
        try{
            AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administración", null, 1);
            SQLiteDatabase db = admin.getWritableDatabase();
            String usuario = usu.getText().toString();
            String contra = cont.getText().toString();
            Cursor fila = db.rawQuery("select residente.nombreUsuario, residente.contraseña from residente where nombreUsuario= '" + usuario+ "' and contraseña= '"+ contra+"'", null);
            if (fila.moveToFirst()) {

                Intent intent = new Intent(this, Principal.class);
                Bundle bun = new Bundle();
                bun.putString("usuario", usu.getText().toString());
                intent.putExtras(bun);

                bund = bun.getString("usuario").toString();
                Toast.makeText(this, "" + bund, Toast.LENGTH_LONG).show();
                startActivity(intent);
            }else
                Toast.makeText(this, "", Toast.LENGTH_LONG).show();
        }catch(Exception ex){
            Toast.makeText(this, ""+ex, Toast.LENGTH_LONG).show();
        }



    }
    public void registrarse(View v) {
        Intent intent = new Intent(this, Registrarse.class );
        startActivity(intent);
    }

}
