package com.example.alex.gudneighbor;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

public class Principal extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
        WebView webView = (WebView) this.findViewById(R.id.webview);
        webView.loadUrl("https://www.banamex.com/es/personas/banca-digital/citibanamex-pay.html ");



    }
    public void btBaja(View v){
        Intent intent= new Intent(this, Baja.class);
        Bundle bun = this.getIntent().getExtras();
        String aux = bun.get("usuario").toString();
        bun.putString("usuario",aux);
        intent.putExtras(bun);

        startActivity(intent);
    }
    public void btModificar(View v){
        Intent intent= new Intent(this, Modificar.class);
        Bundle bun = this.getIntent().getExtras();
        String aux = bun.get("usuario").toString();
        bun.putString("usuario",aux);
        intent.putExtras(bun);

        startActivity(intent);
    }

    public void pantallaAbonar(View v){
        Intent intent = new Intent(this,Abonar.class );
        Bundle bun = this.getIntent().getExtras();
        String aux = bun.get("usuario").toString();
        bun.putString("usuario",aux);
        intent.putExtras(bun);
        Toast.makeText(this, ""+aux, Toast.LENGTH_LONG).show();
        startActivity(intent);

    }
    public void intentcConsultar(View v) {
        Intent intent = new Intent(this, Consultar.class);
        Bundle bun = this.getIntent().getExtras();
        String aux = bun.get("usuario").toString();
        bun.putString("usuario", aux);
        intent.putExtras(bun);
        startActivity(intent);
    }






}
