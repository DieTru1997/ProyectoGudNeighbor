package com.example.alex.gudneighbor;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Abonar extends AppCompatActivity {
    EditText abono, usu, idAbono;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abonar);
        abono=(EditText) findViewById(R.id.etAbonarA);
        idAbono=(EditText) findViewById(R.id.etIdAbonoA);



    }
    public void Abonar(View v){
        try{
            AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administración", null, 1);
            SQLiteDatabase db = admin.getWritableDatabase();

            String idA=idAbono.getText().toString();
            String monto=abono.getText().toString();
            Bundle bun = this.getIntent().getExtras();
            String idUsuario = bun.get("usuario").toString();

            Toast.makeText(this, ""+idUsuario, Toast.LENGTH_LONG).show();


            ContentValues registro = new ContentValues();
            registro.put("idAbono", idA);
            registro.put("monto", monto);
            registro.put("usuario", idUsuario);

            db.insert("abono", null, registro);
            db.close();
            limpia(v);

            Toast.makeText(this, "Felicidades! diste de alta un abono", Toast.LENGTH_LONG).show();

        }catch(Exception ex){
            Toast.makeText(this, "NO  diste de alta un abono:   "+ex, Toast.LENGTH_LONG).show();

        }



    }
    public void limpia (View v){
        usu.setText("");
        abono.setText("");
        idAbono.setText("");

    }
}
