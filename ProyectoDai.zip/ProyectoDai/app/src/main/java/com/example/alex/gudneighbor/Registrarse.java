package com.example.alex.gudneighbor;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Registrarse extends AppCompatActivity {
    EditText nomUsu, cont, nombre,casa, tel, mail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrarse);
        nomUsu = (EditText) findViewById(R.id.etNomUsuario);
        cont = (EditText) findViewById(R.id.etContraseñaR);
        nombre = (EditText) findViewById(R.id.etNombreR);
        casa = (EditText) findViewById(R.id.etCasa);
        tel = (EditText) findViewById(R.id.etTelefono);
        mail = (EditText) findViewById(R.id.etMail);
    }

    public void limpia (View v){
        nomUsu.setText("");
        cont.setText("");
        nombre.setText("");
        casa.setText("");
        tel.setText("");
        mail.setText("");
    }

    public void alta(View v){
        try{
            AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administración", null, 1);
            SQLiteDatabase db = admin.getWritableDatabase();

            String nombreUsuario=nomUsu.getText().toString();
            String contra=cont.getText().toString();
            String nombr=nombre.getText().toString();
            String casaa=casa.getText().toString();
            String telefono=tel.getText().toString();
            String email=mail.getText().toString();

            ContentValues registro = new ContentValues();
            registro.put("nombreUsuario", nombreUsuario);
            registro.put("nombre", nombr);
            registro.put("telefono", telefono);
            registro.put("mail", email);
            registro.put("contraseña", contra);
            registro.put("casa",casaa);


            db.insert("residente", null, registro);
            db.close();
            limpia(v);

            Toast.makeText(this, "Felicidades! te diste de alta", Toast.LENGTH_LONG).show();
        }catch(Exception ex){
            Toast.makeText(this, ""+ex, Toast.LENGTH_LONG).show();
        }


    }
}
