package com.example.alex.gudneighbor;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Baja extends AppCompatActivity {
    EditText nomUsu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_baja);
        nomUsu= (EditText) findViewById(R.id.etNombreUsuarioB);
    }


    public void Limpia (View v){
            nomUsu.setText("");
    }

    public void baja(View v){
        try{
            AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administración", null, 1);
            SQLiteDatabase db = admin.getWritableDatabase();
            String nombreUsuario = nomUsu.getText().toString();
            int cant = db.delete("residente",nombreUsuario = "nombreUsuario" ,null);
            db.close();
            Limpia(v);
            if(cant==1)
                Toast.makeText(this,"se borro al residente", Toast.LENGTH_LONG).show();
            else
                Toast.makeText(this, "no existe el residente con ese usuario",Toast.LENGTH_LONG).show();

        }catch(Exception ex){

            Toast.makeText(this, ""+ex,Toast.LENGTH_LONG).show();

        }

    }



}
