package com.example.alex.gudneighbor;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Consultar extends AppCompatActivity {
    EditText nomUsu, cont, nombre,casa, tel, mail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultar);
        nomUsu = (EditText) findViewById(R.id.etNomUsuarioC);
        cont = (EditText) findViewById(R.id.etContraseñaC);
        nombre = (EditText) findViewById(R.id.etNombreC);
        casa = (EditText) findViewById(R.id.etCasaC);
        tel = (EditText) findViewById(R.id.etTelefonoC);
        mail = (EditText) findViewById(R.id.etMailC);
    }
    public void consulta(View v) {
        try {

            AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administración", null, 1);
            SQLiteDatabase db = admin.getWritableDatabase();
            String nombreUsuario = nomUsu.getText().toString();
            Cursor fila = db.rawQuery("select nombre,casa,telefono,mail, contraseña from residente where nombreUsuario='" + nombreUsuario+"'", null);

            if (fila.moveToFirst()) {
                nombre.setText(fila.getString(0));
                casa.setText(fila.getString(1));
                tel.setText(fila.getString(2));
                mail.setText(fila.getString(3));
                cont.setText(fila.getString(4));

            } else
                Toast.makeText(this, "no existe el alumno en la tabla con dicha clave única", Toast.LENGTH_LONG).show();
            db.close();
        }catch(Exception ex){
            Toast.makeText(this, ""+ex,Toast.LENGTH_LONG).show();
    }

    }


}
