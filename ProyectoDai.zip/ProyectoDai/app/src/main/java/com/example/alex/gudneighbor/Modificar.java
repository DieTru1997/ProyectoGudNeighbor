package com.example.alex.gudneighbor;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.database.Cursor;

public class Modificar extends AppCompatActivity {
    EditText nomUsu, cont, nombreE,casaE, tel, email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar);

        cont = (EditText) findViewById(R.id.etContraseñaM);
        nombreE = (EditText) findViewById(R.id.etNombreM);
        casaE = (EditText) findViewById(R.id.etCasaM);
        tel = (EditText) findViewById(R.id.etTelefonoM);
         email= (EditText) findViewById(R.id.etMailM);
    }
    public void modificar(View v){
        try {

            AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null, 1);
            SQLiteDatabase bd = admin.getWritableDatabase();


            String nombre = nombreE.getText().toString();
            String casa = casaE.getText().toString();
            String telefono = tel.getText().toString();
            String mail = email.getText().toString();
            String contraseña = cont.getText().toString();

            Bundle bun = this.getIntent().getExtras();
            String idUsuario = bun.get("usuario").toString();
            Toast.makeText(this, ""+idUsuario, Toast.LENGTH_LONG).show();




            bd.execSQL("update residente set nombre='"+nombre+"', casa='"+casa+"', telefono='"+telefono+"', mail='"+mail+"', contraseña='"+contraseña+"' where nombreUsuario='"+idUsuario+"'");
            Toast.makeText(this, "Se han modificado los datos ", Toast.LENGTH_LONG).show();



        }catch (Exception ex){
            Toast.makeText(this, ""+ex,Toast.LENGTH_LONG).show();
        }
    }

}
